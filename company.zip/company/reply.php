<?php session_start();
include_once('../includes/config.php');
if (strlen($_SESSION['adminid']==0)) {
  header('location:logout.php');
  } else{
//Code for Updation 
if(isset($_POST['insert']))
    {
        $jtitle=$_POST['jtitle'];
        $jusername=$_POST['jusername'];
        $applicantemail=$_POST['applicantemail'];
        $company=$_POST['company'];
        $companyemail=$_POST['companyemail'];
        $status=$_POST['status'];
        $interviewdate=$_POST['interviewdate'];
        
        $msg=mysqli_query($con,"insert into notifications(jtitle,jusername,applicantemail,company,companyemail,status,interviewdate) 
        values('$jtitle','$jusername','$applicantemail','$company','$companyemail','$status','$interviewdate')");
    
    if($msg)
    {
        echo "<script>alert('Reply sent successfully');</script>";
           echo "<script type='text/javascript'> document.location = 'applicants.php'; </script>";
    }
    }


    
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Employer Reply</title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
        <link href="../css/styles.css" rel="stylesheet" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>
    </head>
    <body class="sb-nav-fixed">
      <?php include_once('includes/navbar.php');?>
        <div id="layoutSidenav">
          <?php include_once('includes/sidebar.php');?>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        
<?php 
$userid=$_GET['uid'];
$query=mysqli_query($con,"select * from jobapplications where id='$userid'");
while($result=mysqli_fetch_array($query))
{?>
                
                        <div class="card mb-4">
                     <form method="post">
                            <div class="card-body">
                                <table class="table table-bordered">
                                   <tr>
                                    <th>Job Title</Title></th>
                                       <td><input class="form-control" id="jtitle" name="jtitle" type="text" value="<?php echo $result['jobtitle'];?>" required /></td>
                                   </tr>
                                   <tr>
                                       <th>Applicant Name</th>
                                       <td><input class="form-control" id="jusername" name="jusername" type="text" value="<?php echo $result['applicant'];?>"  required /></td>
                                   </tr>

                                   <tr>
                                       <th>Applicant Email</th>
                                       <td><input class="form-control" id="applicantemail" name="applicantemail" type="text" value="<?php echo $result['applicantemail'];?>"  required /></td>
                                       </tr>

                                       <tr>
                                       <th>Company</th>
                                       <td><input class="form-control" id="company" name="company" type="text" value="<?php echo $result['company'];?>"  required /></td>
                                       </tr>
                                   <tr>
                                   <tr>
                                       <th>Company Email</th>
                                       <td><input class="form-control" id="companyemail" name="companyemail" type="text" value=" "  required /></td>
                                       </tr>
                                       <th>Application Status</th>
                                       <td colspan="3"><input class="form-control" id="status" name="status" type="text"  /></td>
                                   </tr>
                               
                                     
                                        <tr>
                                       <th>Interview Date</th>
                                       <td colspan="3"> <input class="form-control" id="interviewdate" name="interviewdate" type="date"  required /></td>
                                   </tr>
                                   <tr>
                                       <td colspan="4" style="text-align:center ;"><button type="submit" class="btn btn-primary btn-block" name="insert">Click to reply</button></td>

                                   </tr>
                                    </tbody>
                                </table>
                            </div>
                            </form>
                        </div>
<?php } ?>

                    </div>
                </main>
          <?php include('../includes/footer.php');?>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="../js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="../js/datatables-simple-demo.js"></script>
    </body>
</html>
<?php } ?>
