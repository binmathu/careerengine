<?php session_start();
include_once('../includes/config.php');
if (strlen($_SESSION['adminid']==0)) {
  header('location:logout.php');
  } else{
// for posting a Job
if(isset($_POST['submit']))
{
    $jtitle=$_POST['jtitle'];
    $jdesc=$_POST['jdesc'];
    $location=$_POST['location'];
    $contact=$_POST['contact'];
    $expdate=$_POST['expdate'];
    $cname=$_POST['cname'];
    $email=$_POST['email'];
    $salary=$_POST['salary'];
    $period=$_POST['period'];

//$sql=mysqli_query($con,"select id from company where email='$email'");
//$row=mysqli_num_rows($sql);
//if($row>0)
//{
  //  echo "<script>alert('Email id already exist with another account. Please try with other email id');</script>";
//} else{
    $msg=mysqli_query($con,"insert into jobs(jtitle,jdesc,location,contact,expdate,cname,email,salary,period)
     values('$jtitle','$jdesc','$location','$contact','$expdate','$cname','$email','$salary','$period')");

if($msg)
{
    echo "<script>alert('Registered successfully');</script>";
    //echo "<script type='text/javascript'> document.location = './company/index.php'; </script>";
}
}
}

   ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Manage Users | Employer</title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
        <link href="../css/styles.css" rel="stylesheet" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>

    </head>
    <body class="sb-nav-fixed">
      <?php include_once('includes/navbar.php');?>
        <div id="layoutSidenav">
         <?php include_once('includes/sidebar.php');?>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Post Jobs</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
                            <li class="breadcrumb-item active">Post Jobs</li>
                        </ol>

                            
            
                        <div class="card mb-4">
                            <div class="card-header">
                                <i class="fas fa-table me-1"></i>
                                Post Jobs
                            </div>
                            <div class="card-body">
                                <!---->
                            <form method="post" name="submit" >

                                                <div class="row mb-3">
                                                <div class="">
                                                <div class="form-floating mb-3 mb-md-0">
                                                <input class="form-control" id="jtitle" name="jtitle" type="text" placeholder="Enter the Job Title" required />
                                                <label for="inputjtitle">Job Title</label>
                                                </div>
                                                </div>
                                                                                                

                                                </div>

                                                <div class="form-floating mb-3">
                                                <textarea class="form-control" id="jdesc" name="jdesc" type="text" rows="4" cols="50" placeholder="Enter your Job Description" required> </textarea>
                                                <label for="inputjdesc">Job Description</label>
                                                </div>

                                                <div class="form-floating mb-3">
                                                <input class="form-control" id="location" name="location" type="text" placeholder="Enter the Job Location" required />
                                                <label for="inputlocation">Job Location</label>
                                                </div>
                                                

                                                <div class="form-floating mb-3">
                                                <input class="form-control" id="contact" name="contact" type="text" placeholder="1234567890" required pattern="[0-9]{10}" title="10 numeric characters only"  maxlength="10" required />
                                                <label for="inputcontact">Contact Number</label>
                                                </div>

                                                <div class="form-floating mb-3">
                                                <input class="form-control" id="cname" name="cname" type="text" placeholder="Enter the Company Name" required />
                                                <label for="inputcname">Company Name</label>
                                                </div>

                                                <div class="form-floating mb-3">
                                                <input class="form-control" id="email" name="email" type="email" placeholder="companyname@gmail.com" required />
                                                <label for="inputEmail">Company Email address</label>
                                                </div>

                                                <div class="form-floating mb-3">
                                                <input class="form-control" id="salary" name="salary" type="salary"  required />
                                                <label for="inputEmail">Salary in USD</label>
                                                </div>

                                                <div class="form-floating mb-3">
                                                <input class="form-control" id="period" name="period" type="period" required />
                                                <label for="inputEmail">Job Period</label>
                                                </div>

                                                <div class="form-floating mb-3">
                                                <input class="form-control" id="expdate" name="expdate" type="date" placeholder="Enter the Job Expiration date" required />
                                                <label for="inputexpdate">Job Expiration Date</label>
                                                </div>


                                                        


                                                <div class="row mb-3">
                                                </div>
                                                                                            

                                                <div class="mt-4 mb-0">
                                                <div class="d-grid"><button type="submit" class="btn btn-primary btn-block" name="submit">Post Job</button></div>
                                                </div>
                                                                                        </form>
                            </div>
                        </div>
                    </div>
                </main>
  <?php include('../includes/footer.php');?>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="../js/scripts.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="../js/datatables-simple-demo.js"></script>
    </body>
</html>
<?php  ?>